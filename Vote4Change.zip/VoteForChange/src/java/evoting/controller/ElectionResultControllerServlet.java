
package evoting.controller;

import evoting.dao.CandidateDAO;
import evoting.dao.VoteDAO;
import evoting.dto.CandidateDetails;
import evoting.dto.ElectionResult;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ElectionResultControllerServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = null;
        HttpSession session = request.getSession();
        String userid = (String)session.getAttribute("userid");
        if(userid == null){
            session.invalidate();
            response.sendRedirect("accessdenied.html");
            return;
        }
        String choosen = (String)request.getParameter("data");
        try
        {
            if(choosen != null && choosen.equals("candidate")){
                System.out.println("Inside Servlet candidate");
                Map<String,Integer> result = VoteDAO.getResult();
                Set s = result.entrySet();
                Iterator it = s.iterator();
                LinkedHashMap<CandidateDetails , Integer> resultDetails = new LinkedHashMap<>();
                while(it.hasNext()){
                    Map.Entry<String, Integer> e = (Map.Entry)it.next();
                    CandidateDetails cd = CandidateDAO.getDetailsById(e.getKey());
                    resultDetails.put(cd, e.getValue());
                }
                request.setAttribute("choosen", "candidate");
                request.setAttribute("votecount", VoteDAO.getVoteCount());
                request.setAttribute("result", resultDetails);
                rd = request.getRequestDispatcher("electionresult.jsp");
            }
            else if(choosen != null && choosen.equals("party")){
                
                System.out.println("Inside Servlet party");
                Map<String,Integer> result = VoteDAO.getResultBasedOnParty();
                Set s = result.entrySet();
                Iterator it = s.iterator();
                LinkedHashMap<ElectionResult , Integer> resultDetails = new LinkedHashMap<>();
                while(it.hasNext()){
                    Map.Entry<String, Integer> e = (Map.Entry)it.next();
                    String symbol = CandidateDAO.getSymbolByParty(e.getKey());
                    ElectionResult er = new ElectionResult(e.getKey(), symbol);
                    resultDetails.put(er, e.getValue());
                }
                request.setAttribute("result", resultDetails);
                request.setAttribute("votecount", VoteDAO.getVoteCount());
                request.setAttribute("choosen", "party");
                rd = request.getRequestDispatcher("electionresult.jsp");
                
            }
            else if(choosen != null && choosen.equals("gender")){
                
                request.setAttribute("choosen", "gender");
                System.out.println("Inside Servlet gender");
                String per = VoteDAO.getGenderPercentage();
                System.out.println("Percentage: " + per);
                request.setAttribute("per", per);
                rd = request.getRequestDispatcher("electionresult.jsp");
            }
        }
        catch(Exception ex)
        {
            System.out.println("Exception in ElectionResultControllerServlet");
            ex.printStackTrace();
            request.setAttribute("Exception", ex);
            rd = request.getRequestDispatcher("showexception.jsp");
        }
        finally
        {
            rd.forward(request, response);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
